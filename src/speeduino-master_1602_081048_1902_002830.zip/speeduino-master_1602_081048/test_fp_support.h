#pragma once
#include <stdint.h>

void assert_rounded_div(int32_t a, int32_t b, int32_t actual);